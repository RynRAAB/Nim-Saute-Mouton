
"""Explication Détaillée de l'Aspect Algorithmique:

#### 1. Structure Générale
Le programme utilise `networkx` pour créer et manipuler des graphes, `matplotlib.pyplot` pour visualiser les graphes, et `collections.deque` pour gérer efficacement une file d'attente. Il permet de modéliser et résoudre deux jeux : "Saute-moutons" et "Nim".

#### 2. Génération de l'État Initial
**Saute-moutons**:
- La fonction `generate_initial_state_sheep` crée un état initial composé de `M` moutons blancs ('N'), `M` moutons noirs ('B'), et un espace vide ('X') au centre.

**Nim**:
- La fonction `generate_initial_state_nim` initialise le jeu avec `M` pierres.

#### 3. Identification des Mouvements Valides
**Saute-moutons**:
- La fonction `valid_moves_sheep` trouve tous les mouvements possibles pour un état donné. Les moutons blancs peuvent se déplacer vers la droite ou sauter par-dessus un mouton noir. Les moutons noirs peuvent se déplacer vers la gauche ou sauter par-dessus un mouton blanc.

**Nim**:
- La fonction `valid_moves_nim` génère tous les mouvements possibles pour le jeu de Nim, permettant d'enlever de 1 à `M` pierres.

#### 4. Application des Mouvements
**Saute-moutons**:
- La fonction `apply_move_sheep` applique un mouvement en échangeant les positions dans l'état actuel.

**Nim**:
- La fonction `apply_move_nim` met à jour l'état en enlevant des pierres selon le mouvement spécifié.

#### 5. Génération des Graphes
**Saute-moutons**:
- La fonction `saute_moutons_graph` crée un graphe dirigé représentant les transitions possibles dans le jeu. Elle utilise une file d'attente pour explorer les états, ajoute des nœuds pour chaque nouvel état non visité, et crée des arêtes pour les mouvements valides jusqu'à atteindre un nombre maximal de nœuds.

**Nim**:
- La fonction `nim_graph` crée un graphe dirigé pour le jeu de Nim en utilisant une file d'attente pour explorer les états et en ajoutant des nœuds et des arêtes de manière similaire.

#### 6. Interface Utilisateur et Exécution
- L'utilisateur choisit le jeu, spécifie le nombre de moutons ou de pierres, et le programme génère le graphe correspondant. Le nombre maximal de nœuds est fixé pour limiter la taille du graphe.

#### 7. Recherche du Plus Court Chemin
- Le programme vérifie s'il existe un chemin entre l'état initial et l'état final en utilisant `nx.has_path`. Si un chemin existe, il utilise l'algorithme de Dijkstra pour trouver le plus court chemin (`nx.shortest_path`) et génère un sous-graphe représentant ce chemin.

#### 8. Visualisation et Sauvegarde des Graphes
- Le programme visualise et sauvegarde les graphes générés en tant qu'images en utilisant `matplotlib.pyplot`. Il crée des visualisations distinctes pour le graphe complet des états et le graphe du plus court chemin, en les enregistrant sous des fichiers image.

### Conclusion
Ce programme modélise les jeux de saute-moutons et de Nim en utilisant des graphes, explore les états possibles, et trouve le plus court chemin entre l'état initial et l'état final grâce à l'algorithme de Dijkstra. La visualisation des graphes permet de mieux comprendre les transitions et les solutions optimales dans ces jeux."""

import networkx as nx
import matplotlib.pyplot as plt
from collections import deque

# Génère l'état initial pour le jeu de saute-moutons avec M moutons blancs et M moutons noirs
def generate_initial_state_sheep(M):
    white_sheep = ['N'] * M  # Moutons blancs
    black_sheep = ['B'] * M  # Moutons noirs
    return white_sheep + ['X'] + black_sheep  # État initial avec espace vide au milieu

# Trouve les mouvements valides pour l'état actuel du jeu de saute-moutons
def valid_moves_sheep(state):
    moves = []
    for i in range(len(state)):
        if state[i] == 'N':  # Mouton blanc
            if i + 1 < len(state) and state[i + 1] == 'X':  # Peut bouger d'une case vers la droite
                moves.append((i, i + 1))
            if i + 2 < len(state) and state[i + 2] == 'X':  # Peut sauter par-dessus un mouton noir
                moves.append((i, i + 2))
        elif state[i] == 'B':  # Mouton noir
            if i - 1 >= 0 and state[i - 1] == 'X':  # Peut bouger d'une case vers la gauche
                moves.append((i, i - 1))
            if i - 2 >= 0 and state[i - 2] == 'X':  # Peut sauter par-dessus un mouton blanc
                moves.append((i, i - 2))
    return moves

# Applique un mouvement à l'état actuel du jeu de saute-moutons
def apply_move_sheep(state, move):
    i, j = move
    state[i], state[j] = state[j], state[i]  # Échange les positions

# Génère le graphe pour le jeu de saute-moutons
def saute_moutons_graph(M, max_nodes=100):
    graph = nx.DiGraph()  # Graphe orienté
    initial_state = generate_initial_state_sheep(M)
    initial_state_str = ''.join(initial_state)  # Convertir l'état en chaîne
    final_state = initial_state[::-1]  # État final avec les positions inversées
    final_state_str = ''.join(final_state)  # Convertir l'état final en chaîne
    graph.add_node(initial_state_str, color='purple')  # Couleur de l'état initial
    graph.add_node(final_state_str, color='green')  # Couleur de l'état final

    queue = deque([initial_state])  # File d'attente pour les états à explorer
    visited = set([initial_state_str])  # Ensemble des états visités
    nodes_added = 2  # État initial et état final

    while queue and nodes_added < max_nodes:
        current_state = queue.popleft()  # Prendre le premier état de la file d'attente
        for move in valid_moves_sheep(current_state):  # Pour chaque mouvement valide
            new_state = current_state.copy()
            apply_move_sheep(new_state, move)
            state_str = ''.join(new_state)  # Convertir le nouvel état en chaîne
            if state_str not in visited:
                graph.add_node(state_str)
                visited.add(state_str)
                queue.append(new_state)
                nodes_added += 1
            if nodes_added >= max_nodes:
                break
            graph.add_edge(''.join(current_state), state_str)  # Ajouter une arête entre les états

    return graph, initial_state_str, final_state_str

# Génère l'état initial pour le jeu de Nim avec M pierres
def generate_initial_state_nim(M):
    return M

# Trouve les mouvements valides pour l'état actuel du jeu de Nim
def valid_moves_nim(state):
    moves = []
    for i in range(1, state + 1):  # Peut enlever 1 à M pierres
        moves.append((state, state - i))
    return moves

# Applique un mouvement à l'état actuel du jeu de Nim
def apply_move_nim(state, move):
    return move[1]

# Génère le graphe pour le jeu de Nim
def nim_graph(M, max_nodes=100):
    graph = nx.DiGraph()  # Graphe orienté
    initial_state = generate_initial_state_nim(M)
    graph.add_node(initial_state, color='purple')  # Couleur de l'état initial
    graph.add_node(0, color='green')  # Couleur de l'état final (0 pierres)

    queue = deque([initial_state])  # File d'attente pour les états à explorer
    visited = set([initial_state])  # Ensemble des états visités

    while queue and len(graph) < max_nodes:
        current_state = queue.popleft()  # Prendre le premier état de la file d'attente
        for move in valid_moves_nim(current_state):  # Pour chaque mouvement valide
            new_state = apply_move_nim(current_state, move)
            if new_state not in visited:
                graph.add_node(new_state)
                visited.add(new_state)
                queue.append(new_state)
            graph.add_edge(current_state, new_state)  # Ajouter une arête entre les états

    return graph, initial_state, 0

# Affiche le choix du jeu à l'utilisateur
print("Choisissez le jeu:")
print("1. Saute-mouton")
print("2. Nim")
choice = int(input("Entrez le numéro correspondant au jeu choisi: "))

if choice == 1:
    # Si l'utilisateur choisit le jeu de saute-moutons
    M = int(input("Entrez le nombre de moutons (M) : "))
    max_nodes = 1000  # Nombre maximum de nœuds à ajouter au graphe
    graph, initial_state, final_state = saute_moutons_graph(M, max_nodes=max_nodes)
    filename = "saute_mouton_graphe_colore.png"
else:
    # Si l'utilisateur choisit le jeu de Nim
    M = int(input("Entrez le nombre de pierres (M) : "))
    max_nodes = 1000  # Nombre maximum de nœuds à ajouter au graphe
    graph, initial_state, final_state = nim_graph(M, max_nodes=max_nodes)
    filename = "nim_graphe.png"

# Vérifier si un chemin existe avant de tenter de le trouver
if nx.has_path(graph, initial_state, final_state):
    # Trouver le plus court chemin en utilisant l'algorithme de Dijkstra
    shortest_path = nx.shortest_path(graph, source=initial_state, target=final_state, weight=None, method='dijkstra')

    # Afficher le plus court chemin dans le terminal
    print("Le plus court chemin :", shortest_path)

    # Créer un nouveau graphe pour le plus court chemin
    shortest_path_graph = nx.DiGraph()
    path_edges = list(zip(shortest_path, shortest_path[1:]))  # Créer des arêtes pour le chemin
    shortest_path_graph.add_nodes_from(shortest_path)
    shortest_path_graph.add_edges_from(path_edges)
else:
    # Si aucun chemin n'est trouvé
    print(f"Aucun chemin trouvé entre {initial_state} et {final_state}.")
    shortest_path_graph = None

# Enregistrer le graphe complet en tant que fichier image
plt.figure(figsize=(10, 6))
pos = nx.spring_layout(graph)

# Obtenir les couleurs des nœuds
node_colors = [graph.nodes[node]['color'] if 'color' in graph.nodes[node] else 'lightblue' for node in graph.nodes]

nx.draw_networkx_edges(graph, pos, edgelist=graph.edges(), width=1, alpha=0.5)
nx.draw_networkx_labels(graph, pos, font_size=10, font_weight="bold")
nx.draw_networkx_nodes(graph, pos, node_color=node_colors, node_size=800)

plt.title('Graphe du Jeu (Partiel)')
plt.axis('off')
plt.savefig(filename)
plt.close()

print(f"Graphe enregistré sous '{filename}'")

# Enregistrer le graphe du plus court chemin en tant que fichier image
if shortest_path_graph:
    plt.figure(figsize=(10, 6))
    pos = nx.spring_layout(shortest_path_graph)
    nx.draw(shortest_path_graph, pos, with_labels=True, node_color='lightblue', edge_color='red', node_size=800, font_size=10, font_weight="bold")
    plt.title('Graphe du Plus Court Chemin')
    plt.axis('off')
    shortest_path_filename = "plus_court_chemin_graphe.png"
    plt.savefig(shortest_path_filename)
    plt.close()
    print(f"Graphe du plus court chemin enregistré sous '{shortest_path_filename}'")
