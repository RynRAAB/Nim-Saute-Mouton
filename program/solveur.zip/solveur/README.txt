
"""Explication Détaillée de l'Aspect Algorithmique:

#### 1. Structure Générale
Le programme utilise `networkx` pour créer et manipuler des graphes, `matplotlib.pyplot` pour visualiser les graphes, et `collections.deque` pour gérer efficacement une file d'attente. Il permet de modéliser et résoudre deux jeux : "Saute-moutons" et "Nim".

#### 2. Génération de l'État Initial
**Saute-moutons**:
- La fonction `generate_initial_state_sheep` crée un état initial composé de `M` moutons blancs ('N'), `M` moutons noirs ('B'), et un espace vide ('X') au centre.

**Nim**:
- La fonction `generate_initial_state_nim` initialise le jeu avec `M` pierres.

#### 3. Identification des Mouvements Valides
**Saute-moutons**:
- La fonction `valid_moves_sheep` trouve tous les mouvements possibles pour un état donné. Les moutons blancs peuvent se déplacer vers la droite ou sauter par-dessus un mouton noir. Les moutons noirs peuvent se déplacer vers la gauche ou sauter par-dessus un mouton blanc.

**Nim**:
- La fonction `valid_moves_nim` génère tous les mouvements possibles pour le jeu de Nim, permettant d'enlever de 1 à `M` pierres.

#### 4. Application des Mouvements
**Saute-moutons**:
- La fonction `apply_move_sheep` applique un mouvement en échangeant les positions dans l'état actuel.

**Nim**:
- La fonction `apply_move_nim` met à jour l'état en enlevant des pierres selon le mouvement spécifié.

#### 5. Génération des Graphes
**Saute-moutons**:
- La fonction `saute_moutons_graph` crée un graphe dirigé représentant les transitions possibles dans le jeu. Elle utilise une file d'attente pour explorer les états, ajoute des nœuds pour chaque nouvel état non visité, et crée des arêtes pour les mouvements valides jusqu'à atteindre un nombre maximal de nœuds.

**Nim**:
- La fonction `nim_graph` crée un graphe dirigé pour le jeu de Nim en utilisant une file d'attente pour explorer les états et en ajoutant des nœuds et des arêtes de manière similaire.

#### 6. Interface Utilisateur et Exécution
- L'utilisateur choisit le jeu, spécifie le nombre de moutons ou de pierres, et le programme génère le graphe correspondant. Le nombre maximal de nœuds est fixé pour limiter la taille du graphe.

#### 7. Recherche du Plus Court Chemin
- Le programme vérifie s'il existe un chemin entre l'état initial et l'état final en utilisant `nx.has_path`. Si un chemin existe, il utilise l'algorithme de Dijkstra pour trouver le plus court chemin (`nx.shortest_path`) et génère un sous-graphe représentant ce chemin.

#### 8. Visualisation et Sauvegarde des Graphes
- Le programme visualise et sauvegarde les graphes générés en tant qu'images en utilisant `matplotlib.pyplot`. Il crée des visualisations distinctes pour le graphe complet des états et le graphe du plus court chemin, en les enregistrant sous des fichiers image.

### Conclusion
Ce programme modélise les jeux de saute-moutons et de Nim en utilisant des graphes, explore les états possibles, et trouve le plus court chemin entre l'état initial et l'état final grâce à l'algorithme de Dijkstra. La visualisation des graphes permet de mieux comprendre les transitions et les solutions optimales dans ces jeux."""
